# Bitirme Projesi


## Grup Bilgileri

Grup Adı: Quad-Core  
Project Manager (PM): Ebrar Sude Doğan   
Scrum Master (SM): Kayrahan Toprak Tosun  

## Grup Üyeleri:
- Ebrar Sude Doğan
- Kayrahan Toprak Tosun
- Erdem Baran
- Tuna Kodal

## Bağlantılar

- Google Drive: https://drive.google.com/drive/folders/1lyXuqaJ0JrhiMycv8PPHxm4y8imNcxqK?usp=sharing
- Sprint Board (Jira): https://quadcore.atlassian.net/jira/software/projects/BP/boards/34/timeline?timeline=MONTHS
- GitHub Pages Link: https://tunakodal.github.io/quad-core/ 
